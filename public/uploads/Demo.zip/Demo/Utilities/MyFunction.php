<?php 
    namespace Utilities;

    class MyFunction{
        public static function jsSpecialChars(string $str): string{
            $str = str_replace("\"", "&#34;", $str);
            $str = str_replace("'", "&#39;", $str);

            return str_replace("\\", "&#92;", $str);
        }
    }
?>