<?php 
    namespace DAO;

    use mysqli;
    
    class DBContext{
        private const TRAN_ANH_DUC = array(
            "SERVER_NAME" => "localhost:3306",
            "USER_NAME" => "root",
            "PASSWORD" => "1234",
            "DATABASE_NAME" => "quanlyhoc_db"
        );
        public static function getConnection() : mysqli{
            $con = new mysqli(
                self::TRAN_ANH_DUC["SERVER_NAME"],
                self::TRAN_ANH_DUC["USER_NAME"],
                self::TRAN_ANH_DUC["PASSWORD"],
                self::TRAN_ANH_DUC["DATABASE_NAME"],
            );
            return $con;
        }
        public static function getResult(string $sql, string $types = "", $param = null, array $params = array()) : array{
            $con = self::getConnection();

            if(isset($con->connect_error))
                die($con->connect_error);
                
            $stmt = $con->prepare($sql);

            if(isset($param))
                if(count($params) > 0)
                    $stmt->bind_param($types, $param, ...$params);
                else
                    $stmt->bind_param($types, $param);
                    
            $stmt->execute();

            $result = $stmt->get_result();

            $returnResult = array();

            if($result->num_rows > 0){
                $row = $result->fetch_assoc();
                while($row){
                    $returnResult[] = $row;
                    $row = $result->fetch_assoc();
                }
            }

            $stmt->close();
            $con->close();

            return $returnResult;
        }

        public static function update(string $sql, string $types = "", $param = null, array $params = array()) : bool|string{
            $con = self::getConnection();

            if(isset($con->connect_error))
                die($con->connect_error);

            $stmt = $con->prepare($sql);

            if(isset($param))
                if(count($params) > 0)
                    $stmt->bind_param($types, $param, ...$params);
                else
                    $stmt->bind_param($types, $param);
                    
            if($stmt->execute()){
                $stmt->close();
                $con->close();
                return true;
            }
            else{
                $message = $con->error;
                $stmt->close();
                $con->close();
                return $message;
            }
        }
    }
?>