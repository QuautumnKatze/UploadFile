<?php 
    $x = "Hello World";

    include $_SERVER["DOCUMENT_ROOT"] . "/Demo/View/Test.php";
?>