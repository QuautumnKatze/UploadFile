export const arrayReverse = arr => arr.reverse();
