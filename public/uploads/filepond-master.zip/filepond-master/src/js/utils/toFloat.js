import { toNumber } from './toNumber';
export const toFloat = value => parseFloat(toNumber(value));
